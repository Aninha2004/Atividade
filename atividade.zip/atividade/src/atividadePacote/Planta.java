package atividadePacote;

public class Planta {
	
	public void fotossintese() 
	{
		System.out.println("Realizando fotossintese");
	}

}
