package atividadePacote;

public class Flor extends Planta{
	
	public void fotossintese()
	{
	
	System.out.println("Isso é uma flor fazendo fotossintese");
	
	}

}
