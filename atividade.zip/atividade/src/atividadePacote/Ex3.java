package atividadePacote;

public class Ex3 {
	
	public static void main(String[] args)
	{
		Flor flor = new Flor();
		Planta planta = new Planta();
		Arvore arvore = new Arvore();
		
		flor.fotossintese();
		planta.fotossintese();
		arvore.fotossintese();
	}

}
