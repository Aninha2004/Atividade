package atividadePacote;

public class Arvore extends Planta {
	
	public void fotossintese()
	{
		System.out.println("Isto é uma Árvore fazendo fotossintese");
	}

}
