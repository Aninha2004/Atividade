package atividadePacote;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.util.List;

public class Ex1 {
	public static void main(String[] args) {
		
		List<Integer> minhaLista = new ArrayList<Integer>();
		
		minhaLista.add(1);
		minhaLista.add(2);
		minhaLista.add(3);
		minhaLista.add(4);
		minhaLista.add(5);
		minhaLista.add(6);
		
		
		System.out.println(minhaLista);
	}
}
